from ExtractPII import ExtractPII
import pprint

if __name__ == "__main__":
    pp = pprint.PrettyPrinter(indent=4)
    text_test = """409-52-2002 409522002d  X4012888888881881 X409522002d x409-52-2002y , hoahaf,asdf fjdwqanvqr 3{{wgflñw}}
    vevw v fgr t54yh64  078-05-1120g5ty245 gffsdv  123-45-6789)  219-09-9999, feve 078-05-1120 378282246310005
    uferugf24384f 1cf ,xz,.VW. ,33R23| 409-52-2002 KKK 000-00-0000, 111-11-1111, 222-22-2222, 371449635398431
	grghtbh534 378734493671000  gh45bh54 f30569309025904,
	fergfqewr  38520000023237 , gtbgtr 6011111111111117,  3530111333300000 tbbt v 4012888888881881	 g
	gfewfvwrv3g XXXXXXXXX kayla= 609324948
    X409522002d hoahaf,asdf fjdwqanvqr 3{{wgflñw}}
    vevw v fgr t54yh64  078051120g5ty245 gffsdv  12345-6789)  219-09-999, feve 078051120 
	36042258651439
	5555555555554444,grev re 5105105105105100 vewdvwe ñ-ñp., 4111111111111111
    30569309025904
    409522002 6011111111111117"""

    response = ExtractPII(text_test)
    print("*" * 60)
    print("ALL SSN WITH '-' \n")
    pp.pprint(response.extract_ssn())
    print("*" * 60)
    print("ALL SSN WITHOUT '-' \n")
    pp.pprint(response.extract_ssn(stripe=False))
    print("*" * 60)
    print("ALL CREDIT CARDS NUMBERS \n")
    pp.pprint(response.extract_credit_card_numbers())

